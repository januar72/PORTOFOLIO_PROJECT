<?php 
include 'koneksi.php';
$id =$_GET['id'];

$hapus =mysqli_query($konek, "DELETE FROM tb_user WHERE id_user='$id'");
header("location:dashboard_admin.php?p=data_pengguna&notif=hapus");

 ?>