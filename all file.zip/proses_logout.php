<?php 
session_start();
unset($_SESSION['masuk']);
echo "<script>alert('proses logout sukses..!');
document.location.href='login.php'
</script>\n";

 ?>