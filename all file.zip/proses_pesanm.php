<?php 
include 'koneksi.php';

$nama =$_POST['nama'];
$email =$_POST['email'];
$hp =$_POST['hp'];
$pesan =$_POST['pesan'];

$simpan=mysqli_query($konek, "INSERT INTO `tb_pesan` (`id_pesan`,`nama`,`email`,`hp`,`pesan`) VALUES (null, '$nama','$email','$hp','$pesan') ");
header("index.php");

 ?>