<?php 
include 'koneksi.php';
if (isset($_POST['simpan'])) {
	$direktori ="berkas/";
	$file_name =$_FILES['foto']['name'];
	$nama_file=$_FILES['gambar']['name'];
	move_uploaded_file($_FILES['foto']['tmp_name'],$direktori.$file_name);
	move_uploaded_file($_FILES['gambar']['tmp_name'],$direktori.$nama_file);

	$judul =$_POST['judul'];
	$kategori =$_POST['kategori'];
	$tgl_muat =$_POST['tgl_muat'];
	$nm_penulis =$_POST['nm_penulis'];
	$isi =$_POST['isi'];

	$simpan=mysqli_query($konek, "INSERT INTO `tb_berita` (`id_berita`,`judul`,`kategori`,`gambar`,`tgl_muat`,`nm_penulis`,`foto`,`isi`) VALUES (null, '$judul','$kategori', '$nama_file','$tgl_muat','$nm_penulis','$file_name', '$isi')");

	header("location:dashboard_admin.php?p=data_blog");
}

 ?>

 