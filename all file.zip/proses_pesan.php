<?php 
include 'koneksi.php';
if (isset($_POST['simpan'])) {
$nama =$_POST['nama'];
$email =$_POST['email'];
$hp =$_POST['hp'];
$isi =$_POST['isi'];

$tampil=mysqli_query($konek, "SELECT * FROM tb_pesan WHERE nama='nama'");
$data_a=mysqli_num_rows($tampil);
$data_b=mysqli_fetch_array($tampil);
if ($data_a > 0) {
	header("location:dashboard_admin.php?p=data_pesan&notif=gagal");
}elseif($data_a == 0){
	$simpan=mysqli_query($konek, "INSERT INTO tb_pesan (`id_pesan`,`nama`,`email`,`hp`,`isi`) VALUES (null, '$nama','$email','$hp','$isi')");
header("location:dashboard_admin.php?p=data_pesan&notif=sukses");

}
}

 ?>