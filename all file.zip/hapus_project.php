<?php 
include 'koneksi.php';
$id =$_GET['id'];

$hapus =mysqli_query($konek, "DELETE FROM tb_project WHERE id_prj='$id'");
header("location:dashboard_admin.php?p=data_project");
 ?>