<?php 
session_start();
include 'koneksi.php';
if (isset($_POST['masuk'])) {
	$user =$_POST['Username'];
	$pass =$_POST['Password'];
	$tampil=mysqli_query($konek, "SELECT * FROM tb_user WHERE username='$user' AND password='$pass' AND status='Aktif'");
	$result =mysqli_num_rows($tampil);
	$data=mysqli_fetch_array($tampil);
	if ($result > 0) {
		if ($data['jabatan'] == 'Admin') {
			$_SESSION['masuk'] = $user;
			header("location:dashboard_admin.php");
		}elseif ($data['jabatan'] == 'Owner') {
			$_SESSION['masukone'] = $user;
			header("location:dashboard_owner.php");
		}
	}elseif ($result == 0) {
		header("location:login.php?notif=gagal");
	}
}

 ?>