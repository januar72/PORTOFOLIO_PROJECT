<?php include 'tem/header.php'; ?>
    <div class="stricky-header stricked-menu main-menu">
            <div class="sticky-header__content"></div><!-- /.sticky-header__content -->
        </div><!-- /.stricky-header -->

        <section class="main-slider">
            <div class="swiper-container thm-swiper__slider" data-swiper-options='{
        "slidesPerView": 1,
        "loop": true,
        "effect": "fade",
        "autoplay": {
            "delay": 5000
        },
        "navigation": {
            "nextEl": "#main-slider__swiper-button-next",
            "prevEl": "#main-slider__swiper-button-prev"
        }
    }'>
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <div class="image-layer" style="background-image: url(assets/images/main-slider/);">
                        </div>
                        <!-- /.image-layer -->
                        <div class="container">
                            <div class="row">
                                <div class="col-xl-7 col-lg-7">
                                    <span class="tagline">Welcome JL Project</span>
                                    <h2><span>Jl Project</span> <br>
                                        & Team</h2>
                                    <p>Hy mari bergabung bersama kami JL Project, dalam memajukan industri bisnis anda <br> Kami siap membantu dengan senang hati dalam mengelolah data kedalam sebuah website resmi pertama Mu. harga  terjangkau.</p>
                                    <a href="projects.php" class=" thm-btn">Info Selanjutnya</a>
                                    <!-- /.thm-btn dynamic-radius -->
                                </div><!-- /.col-lg-7 text-right -->
                            </div><!-- /.row -->
                        </div><!-- /.container -->
                    </div><!-- /.swiper-slide -->
                </div><!-- /.swiper-wrapper -->

                <!-- If we need navigation buttons -->
                

            </div><!-- /.swiper-container thm-swiper__slider -->
        </section><!-- /.main-slider -->

        <section class="service-one">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-lg-4 wow fadeInUp" data-wow-duration="1500ms">
                        <div class="service-one__box">
                            <img src="depan/assets/images/services/elektro-1-1.jpg" alt="">
                            <div class="service-one__box-content">
                                <h3><a href="#">Website Perusahaan</a></h3>
                            </div><!-- /.service-one__box-content -->
                        </div><!-- /.service-one__box -->
                    </div><!-- /.col-md-12 col-lg-4 -->
                    <div class="col-md-12 col-lg-4 wow fadeInUp" data-wow-duration="1500ms">
                        <div class="service-one__box">
                            <img src="depan/assets/images/services/elektro-2-1.jpg" alt="">
                            <div class="service-one__box-content">
                                <h3><a href="#">Website Pariwisata</a></h3>
                            </div><!-- /.service-one__box-content -->
                        </div><!-- /.service-one__box -->
                    </div><!-- /.col-md-12 col-lg-4 -->
                    <div class="col-md-12 col-lg-4 wow fadeInUp" data-wow-duration="1500ms">
                        <div class="service-one__box">
                            <img src="depan/assets/images/services/elektro-2-3.jpg" alt="">
                            <div class="service-one__box-content">
                                <h3><a href="#">Website UMKM</a></h3>
                            </div><!-- /.service-one__box-content -->
                        </div><!-- /.service-one__box -->
                    </div><!-- /.col-md-12 col-lg-4 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </section><!-- /.service-one -->

        <section class="about-one">
            <div class="container">
                <div class="row">
                    <div class="col-lg-5">
                        <div class="about-one__images">
                            <img src="depan/assets/images/resources/about-1-1.jpg" alt="">
                            <div class="about-one__count wow fadeInLeft" data-wow-duration="1500ms">
                                <span>Gratis Perawatan</span>
                                <h4>24 Jam</h4>
                            </div><!-- /.about-one__count -->
                        </div><!-- /.about-one__images -->
                    </div><!-- /.col-lg-6 -->
                    <div class="col-lg-7">
                        <div class="about-one__content">
                            <div class="block-title text-left">
                                <p>Welcome to Jl Project</p>
                                <h3>Teknologi untuk Masa Depan yang Lebih Baik</h3>
                            </div><!-- /.block-title -->
                            <div class="about-one__tagline">
                                <p>Kami memiliki pengalaman 3 tahun dalam pengembangan teknologi.</p>
                            </div><!-- /.about-one__tagline -->
                            <div class="about-one__summery">
                                <p>Kami Sangat Menghargai Keluhan dan kesepakatan dalam menyelesaikan project website yang sudah memenuhi kesepakatan.</p>
                            </div><!-- /.about-one__summery -->
                            <div class="about-one__icon-row">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="about-one__box">
                                             <i class="fa fa-laptop"></i> 
                                            <h4><a href="">Professional developer</a></h4>
                                        </div><!-- /.about-one__box -->
                                    </div><!-- /.col-lg-6 -->
                                    <div class="col-lg-6">
                                        <div class="about-one__box">
                                            <i class="fa fa-fw fa-cogs"></i> 
                                            <h4><a href="">Free Maintenance</a></h4>
                                        </div><!-- /.about-one__box -->
                                    </div><!-- /.col-lg-6 -->
                                </div><!-- /.row -->
                            </div><!-- /.about-one__icon-row -->
                            <a href="about.php" class="thm-btn">Lihat Selanjutnya</a><!-- /.thm-btn -->
                        </div><!-- /.about-one__content -->
                    </div><!-- /.col-lg-6 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </section><!-- /.about-one -->

        <section class="service-two">
            <div class="service-two__bottom-curv"></div><!-- /.service-two__bottom-curv -->
            <div class="container">
                <div class="block-title text-center">
                    <!-- /.block-title__image -->
                    <p>List Layanan</p>
                    <h3>Layanan Kami</h3>
                </div><!-- /.block-title -->
                <div class="row">
                    <div class="col-sm-12 col-md-6 col-lg-3">
                        <div class="service-two__card">
                            <div class="service-two__card-image">
                                <img src="depan/assets/images/services/elektro-2-3.jpg" alt="">
                            </div><!-- /.service-two__card-image -->
                            <div class="service-two__card-content">
                                <div class="service-two__card-icon">
                                    <i class="fa fa-laptop"></i>
                                </div><!-- /.service-two__card-icon -->
                                <h3><a href="projects.php">Website Perusahaan</a></h3>
                               <p>Kami menerima pengerjaan project sekala kecil maupun sekala besar.</p>
                            </div><!-- /.service-two__card-content -->
                        </div><!-- /.service-two__card -->
                    </div><!-- /.col-sm-12 col-md-6 col-lg-3 -->
                    <div class="col-sm-12 col-md-6 col-lg-3">
                        <div class="service-two__card">
                            <div class="service-two__card-image">
                                <img src="depan/assets/images/services/elektro-1-1.jpg" alt="">
                            </div><!-- /.service-two__card-image -->
                            <div class="service-two__card-content">
                                <div class="service-two__card-icon">
                                    <i class="fa fa-fw fa-bus"></i>
                                </div><!-- /.service-two__card-icon -->
                                <h3><a href="projects.php">Website Destinasi Wisata</a></h3>
                                <p>Kami menerima pengerjaan project sekala kecil maupun sekala besar.</p>
                            </div><!-- /.service-two__card-content -->
                        </div><!-- /.service-two__card -->
                    </div><!-- /.col-sm-12 col-md-6 col-lg-3 -->
                    <div class="col-sm-12 col-md-6 col-lg-3">
                        <div class="service-two__card">
                            <div class="service-two__card-image">
                                <img src="depan/assets/images/services/elektro-2-1.jpg" alt="">
                            </div><!-- /.service-two__card-image -->
                            <div class="service-two__card-content">
                                <div class="service-two__card-icon">
                                    <i class="fa fa-fw fa-home"></i>
                                </div><!-- /.service-two__card-icon -->
                                <h3><a href="projects.php">Website Pemerintah</a></h3>
                                <p>Kami menerima pengerjaan project sekala kecil maupun sekala besar.</p>
                            </div><!-- /.service-two__card-content -->
                        </div><!-- /.service-two__card -->
                    </div><!-- /.col-sm-12 col-md-6 col-lg-3 -->
                    <div class="col-sm-12 col-md-6 col-lg-3">
                        <div class="service-two__card">
                            <div class="service-two__card-image">
                                <img src="depan/assets/images/services/servis-2-1.jpg" alt="">
                            </div><!-- /.service-two__card-image -->
                            <div class="service-two__card-content">
                                <div class="service-two__card-icon">
                                    <i class="fa fa-fw fa-users"></i> 
                                </div><!-- /.service-two__card-icon -->
                                <h3><a href="projects.php">Website Forum/Perorangan</a></h3>
                                <p>Kami menerima pengerjaan project sekala kecil maupun sekala besar.</p>
                            </div><!-- /.service-two__card-content -->
                        </div><!-- /.service-two__card -->
                    </div><!-- /.col-sm-12 col-md-6 col-lg-3 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </section><!-- /.service-two -->

        <div class="projects-one project-one__home-one">
            <div class="container">
                <div class="block-title text-center"><!-- /.block-title__image -->
                    <p>Daftar Project Terbaru</p>
                </div><!-- /.block-title -->
                <div class="thm-swiper__slider swiper-container" data-swiper-options='{"spaceBetween": 0, "slidesPerView": 1, "loop": true, "slidesPerGroup": 1, "pagination": {
            "el": "#projects-one__swiper-pagination",
            "type": "bullets",
            "clickable": true
        },
        "breakpoints": {
            "0": {
                "spaceBetween": 0,
                "slidesPerView": 1,
                "slidesPerGroup": 1
            },
            "640": {
                "spaceBetween": 30,
                "slidesPerView": 2,
                "slidesPerGroup": 2
            },
            "992": {
                "spaceBetween": 30,
                "slidesPerView": 2,
                "slidesPerGroup": 2
            }
        }}'>
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <div class="projects-one__single">
                                <img src="depan/assets/images/projects/project-2-1.jpg" alt="">
                                <div class="projects-one__content">
                                    <h3>Innovation</h3>
                                    <a href="projects.php" class="projects-one__button"><i class="agrikon-icon-right-arrow"></i></a><!-- /.projects-one__button -->
                                </div><!-- /.projects-one__content -->
                            </div><!-- /.projects-one__single -->
                        </div><!-- /.swiper-slide -->
                        <div class="swiper-slide">
                            <div class="projects-one__single">
                                <img src="depan/assets/images/projects/project-2-2.jpg" alt="">
                                <div class="projects-one__content">
                                    <h3>Innovation</h3>
                                    <a href="projects.php" class="projects-one__button"><i class="agrikon-icon-right-arrow"></i></a><!-- /.projects-one__button -->
                                </div><!-- /.projects-one__content -->
                            </div><!-- /.projects-one__single -->
                        </div><!-- /.swiper-slide -->
                        <div class="swiper-slide">
                            <div class="projects-one__single">
                                <img src="depan/assets/images/projects/project-2-3.jpg" alt="">
                                <div class="projects-one__content">
                                    <h3>Innovation</h3>
                                    <a href="projects.php" class="projects-one__button"><i class="agrikon-icon-right-arrow"></i></a><!-- /.projects-one__button -->
                                </div><!-- /.projects-one__content -->
                            </div><!-- /.projects-one__single -->
                        </div><!-- /.swiper-slide -->
                        <div class="swiper-slide">
                            <div class="projects-one__single">
                                <img src="depan/assets/images/projects/project-2-1.jpg" alt="">
                                <div class="projects-one__content">
                                    <h3>Innovation</h3>
                                    <a href="projects.php" class="projects-one__button"><i class="agrikon-icon-right-arrow"></i></a><!-- /.projects-one__button -->
                                </div><!-- /.projects-one__content -->
                            </div><!-- /.projects-one__single -->
                        </div><!-- /.swiper-slide -->
                        <div class="swiper-slide">
                            <div class="projects-one__single">
                                <img src="depan/assets/images/projects/project-2-2.jpg" alt="">
                                <div class="projects-one__content">
                                    <h3>Innovation</h3>
                                    <a href="projects.php" class="projects-one__button"><i class="agrikon-icon-right-arrow"></i></a><!-- /.projects-one__button -->
                                </div><!-- /.projects-one__content -->
                            </div><!-- /.projects-one__single -->
                        </div><!-- /.swiper-slide -->
                        <div class="swiper-slide">
                            <div class="projects-one__single">
                                <img src="depan/assets/images/projects/project-2-3.jpg" alt="">
                                <div class="projects-one__content">
                                    <h3>Innovation</h3>
                                    <a href="projects.php" class="projects-one__button"><i class="agrikon-icon-right-arrow"></i></a><!-- /.projects-one__button -->
                                </div><!-- /.projects-one__content -->
                            </div><!-- /.projects-one__single -->
                        </div><!-- /.swiper-slide -->
                    </div><!-- /.swiper-wrapper -->
                    <div class="swiper-pagination" id="projects-one__swiper-pagination"></div>
                </div><!-- /.swiper-container -->
            </div><!-- /.container -->
        </div><!-- /.projects-one -->

      
        <section class="gray-boxed-wrapper home-one__boxed" style="margin-top: 50px;">
            <section class="blog-home-two blog-home-one">
                <div class="container">
                    <div class="row top-row">
                        <div class="col-lg-6">
                            <div class="block-title">
                                <h3>Berita Dan Artikel Terbaru</h3>
                            </div><!-- /.block-title -->
                        </div><!-- /.col-lg-6 -->
                        <div class="col-lg-6">
                            <p class="block-text">Perlu di ketahui bahwa kami selalu memuat berita terbaru berkaitan dengan teknologi dan lainya.</p>
                        </div><!-- /.col-lg-6 -->
                    </div><!-- /.row -->
                    <div class="row">
                        <?php include 'koneksi.php';
                        $tampil=mysqli_query($konek, "SELECT * FROM tb_berita");
                        while ($data=mysqli_fetch_array($tampil, MYSQLI_ASSOC)) {?>
                        <div class="col-md-12 col-lg-4">
                            <div class="blog-card">
                                <div class="blog-card__image">
                                    <img src="./berkas/<?php echo $data['gambar']; ?>" alt="Best Way to Do Eco and Agriculture">
                                    <a href="blog-details.php?id=<?php echo $data['id_berita']; ?>"></a>
                                </div><!-- /.blog-card__image -->

                                <div class="blog-card__content">
                                    <div class="blog-card__date" style="font-size: 10px;"><?php echo $data['tgl_muat']; ?></div><!-- /.blog-card__date -->
                                    <div class="blog-card__meta">
                                        <a href="blog-details.php?id=<?php echo $data['id_berita']; ?>"><i class="far fa-user-circle"></i> by <?php echo $data['nm_penulis']; ?></a>
                                        <a href="blog-details.php?id=<?php echo $data['id_berita']; ?>"></a>
                                    </div><!-- /.blog-card__meta -->
                                    <h3><a href="blog-details.php?id=<?php echo $data['id_berita']; ?>"><?php echo $data['judul']; ?></a></h3>
                                    <a href="blog-details.php?id=<?php echo $data['id_berita']; ?>" class="thm-btn">Baca Selnjutnya</a><!-- /.thm-btn -->
                                </div><!-- /.blog-card__content -->
                            </div><!-- /.blog-card -->
                        </div><!-- /.col-md-12 col-lg-4 -->
                        <?php } ?>
                    </div><!-- /.row -->
                    <hr />
                </div><!-- /.container -->
            </section><!-- /.blog-home-two -->
        </section><!-- /.gray-boxed-wrapper -->

        <section class="contact-two">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-12 col-xl-5">
                        <div class="contact-two__image">
                            <img src="depan/assets/images/resources/about-1-1.jpg" class="img-fluid" alt="">
                        </div><!-- /.contact-two__image -->
                    </div><!-- /.col-sm-12 col-md-12 col-lg-12 col-xl-5 -->
                    <div class="col-sm-12 col-md-12 col-lg-12 col-xl-3">
                        <div class="contact-two__content">
                            <div class="block-title">
                                <h3>Kontak Kami</h3>
                            </div><!-- /.block-title -->
                            <div class="contact-two__summery">
                                <p>Jangan Lupa menghubungi kami lebih lanjut, dengan memgisi daftar berikut :</p>
                            </div><!-- /.contact-two__summery -->
                        </div><!-- /.contact-two__content -->
                    </div><!-- /.col-sm-12 col-md-12 col-lg-12 col-xl-4 -->
                    <div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
                        <form action="proses_pesanm.php" method="post" class="contact-one__form contact-form-validated">
                            <div class="row">
                                <div class="col-lg-12">
                                    <input type="text" name="nama" placeholder="Nama Lengkap">
                                </div><!-- /.col-lg-6 -->
                                <div class="col-lg-12">
                                    <input type="text" name="email" placeholder="Masukan Email">
                                </div><!-- /.col-lg-6 -->
                                <div class="col-lg-12">
                                    <input type="text" name="hp" placeholder="Nomor Hp">
                                </div><!-- /.col-lg-6 -->
                                <div class="col-lg-12">
                                    <textarea name="pesan" placeholder="Tulis Pesan"></textarea>
                                </div><!-- /.col-lg-12 -->
                                <div class="col-lg-12">
                                    <button type="submit" class="thm-btn">Kirim Pesan</button><!-- /.thm-btn -->
                                </div><!-- /.col-lg-12 -->
                            </div><!-- /.row -->
                        </form>
                    </div><!-- /.col-sm-12 col-md-12 col-lg-12 col-xl-4 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </section><!-- /.contact-two -->

<?php include 'tem/footer.php'; ?>