<?php include 'tem/header.php'; ?>
        <div class="stricky-header stricked-menu main-menu">
            <div class="sticky-header__content"></div><!-- /.sticky-header__content -->
        </div><!-- /.stricky-header -->
        <section class="page-header">
            <div class="page-header__bg" ></div>
            <!-- /.page-header__bg -->
            <div class="container">
                <ul class="thm-breadcrumb list-unstyled">
                    <li><a href="index.html">Home</a></li>
                    <li>/</li>
                    <li><span>Detail Project</span></li>
                </ul><!-- /.thm-breadcrumb list-unstyled -->
                <h2>Detail Project</h2>
            </div><!-- /.container -->
        </section><!-- /.page-header -->

        <section class="project-details">
            <div class="container">
                <?php include 'koneksi.php';
                $id =$_GET['id'];
                $tampil=mysqli_query($konek, "SELECT * FROM tb_project WHERE id_prj='$id'");
                while ($data=mysqli_fetch_array($tampil, MYSQLI_ASSOC)) { ?>
                <img src="./berkas/<?php echo $data['foto']; ?>" class="img-fluid" alt="">
                <ul class="list-unstyled project-details__list">
                    <li>
                        <span>Tanggal:
                        </span>
                        <?php echo $data['tgl']; ?>
                    </li>
                    <li>
                        <span>Pelanggan:
                        </span>
                        <?php echo $data['pelanggan']; ?>
                    </li>
                    <li>
                        <span>Kategori:
                        </span>
                        <?php echo $data['kategori']; ?>
                    </li>
                    <li>
                        <span>Layanan:
                        </span>
                        <?php echo $data['layanan']; ?>
                    </li>
                </ul><!-- /.list-unstyled project-details__list -->
                <h2><?php echo $data['judul']; ?></h2>
                <p>
                    <?php echo $data['isi']; ?>
                </p>
            <?php } ?>

                <div class="bottom-content">
                    <div class="row">
                        <div class="col-lg-6">
                            <h3>Fakta Menarik dan menantang dalam Membuat Project Website</h3>
                            <p>Ada berbagai hal menarik ni guys.. dan hal-hal lain yang tentunya sangat menyenangkan dalam membuat website ini yaa tentunya kekompakan dan kesinambungan antara project Men dan Client ya. dan berbagai hal lain seperti dibawah ini:</p>
                            <ul class="list-unstyled project-details__check-list">
                                <li>
                                    <i class="fa fa-check-circle"></i>
                                    Proses pengerjaan dalam waktu kurang lebih 2 minggu
                                </li>
                                <li>
                                    <i class="fa fa-check-circle"></i>
                                    Proses pengambilan data yang cukup kompleks.
                                </li>
                                <li>
                                    <i class="fa fa-check-circle"></i>
                                    Team Yang solid dalam Menyelesaikan Project.
                                </li>
                            </ul><!-- /.list-unstyled -->
                        </div><!-- /.col-lg-6 -->
                        <div class="col-lg-6">
                            <div class="project-details__images">
                                <img src="depan/assets/images/projects/prk.jpg" alt="">
                                <img src="depan/assets/images/projects/project-d-2-2.jpg" alt="">
                            </div><!-- /.project-details__images -->
                        </div><!-- /.col-lg-6 -->
                    </div><!-- /.row -->
                </div><!-- /.bottom-content -->
            </div><!-- /.container -->
        </section><!-- /.project-details -->
<?php include 'tem/footer.php'; ?>