<?php 
include 'koneksi.php';
if (isset($_POST['simpan'])) {
$direktori ="berkas/";
$file_name =$_FILES['gambar']['name'];
move_uploaded_file($_FILES['gambar']['tmp_name'],$direktori.$file_name);

$nama =$_POST['nama'];
$username =$_POST['username'];
$password =$_POST['password'];
$jabatan =$_POST['jabatan'];

$tampil =mysqli_query($konek, "SELECT * FROM tb_user WHERE username='$username'");
$tampil_satu =mysqli_num_rows($tampil);
$data =mysqli_fetch_array($tampil);
if ($tampil_satu > 0) {
	header("location:dashboard_admin.php?p=data_pengguna&notif=gagal");
}elseif ($tampil_satu == 0) {
	$simpan =mysqli_query($konek, "INSERT INTO `tb_user` (`id_user`,`nama`,`username`,`password`,`jabatan`,`status`,`gambar`) VALUES (null, '$nama','$username','$password','$jabatan','Aktif','$file_name')");
	header("location:dashboard_admin.php?p=data_pengguna&notif=sukses");
}
}
 ?>