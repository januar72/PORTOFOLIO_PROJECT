<?php include 'tem/header.php'; ?>
        <div class="stricky-header stricked-menu main-menu">
            <div class="sticky-header__content"></div><!-- /.sticky-header__content -->
        </div><!-- /.stricky-header -->
        <section class="page-header">
            <div class="page-header__bg"></div>
            <!-- /.page-header__bg -->
            <div class="container">
                <ul class="thm-breadcrumb list-unstyled">
                    <li><a href="index.php">Home</a></li>
                    <li>/</li>
                    <li><span>Berita</span></li>
                </ul><!-- /.thm-breadcrumb list-unstyled -->
                <h2>Kotak Berita</h2>
            </div><!-- /.container -->
        </section><!-- /.page-header -->

        <section class="blog-grid">
            <div class="container">
                <div class="row">
                    <?php include 'koneksi.php';
                    $tampil=mysqli_query($konek, "SELECT * FROM tb_berita ");
                    while ($data=mysqli_fetch_array($tampil, MYSQLI_ASSOC)) {?>
                    <div class="col-md-6 col-lg-4">
                        <div class="blog-card">
                            <div class="blog-card__image">
                                <img src="./berkas/<?php echo $data['gambar']; ?>" alt="Best Way to Do Eco and Agriculture">
                                <a href="blog-details.php?id=<?php echo $data['id_berita']; ?>"></a>
                            </div><!-- /.blog-card__image -->
                            <div class="blog-card__content">
                                <div class="blog-card__date" style="font-size: 12px;"><?php echo $data['tgl_muat']; ?></div><!-- /.blog-card__date -->
                                <div class="blog-card__meta">
                                    <a href="blog-details.php?id=<?php echo $data['id_berita']; ?>"><i class="far fa-user-circle"></i> by <?php echo $data['nm_penulis']; ?></a>
                                    <a href="blog-details.php"><i class="far fa-comments"></i> 2 Comments</a>
                                </div><!-- /.blog-card__meta -->
                                <h3><a href="blog-details.php?id=<?php echo $data['id_berita']; ?>"><?php echo $data['judul']; ?></a></h3>
                                <a href="blog-details.php?id=<?php echo $data['id_berita']; ?>" class="thm-btn">Baca Selengkapnya</a><!-- /.thm-btn -->
                            </div><!-- /.blog-card__content -->
                        </div><!-- /.blog-card -->
                    </div><!-- /.col-md-6 col-lg-4 -->
                <?php } ?>
                </div><!-- /.row -->
                <div class="text-center more-btn__box">
                    <a href="projects.php" class="thm-btn">Lihat Selanjutnya</a><!-- /.thm-btn -->
                </div><!-- /.text-center -->
            </div><!-- /.container -->
        </section><!-- /.blog-grid -->
<?php include 'tem/footer.php'; ?>