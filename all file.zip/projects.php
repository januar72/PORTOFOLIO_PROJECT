<?php include 'tem/header.php'; ?>
        <div class="stricky-header stricked-menu main-menu">
            <div class="sticky-header__content"></div><!-- /.sticky-header__content -->
        </div><!-- /.stricky-header -->
        <section class="page-header">
            <div class="page-header__bg" style="background-image: url(assets/images/backgrounds/);"></div>
            <!-- /.page-header__bg -->
            <div class="container">
                <ul class="thm-breadcrumb list-unstyled">
                    <li><a href="index.php">Home</a></li>
                    <li>/</li>
                    <li><span>Projects</span></li>
                </ul><!-- /.thm-breadcrumb list-unstyled -->
                <h2>Projects</h2>
            </div><!-- /.container -->
        </section><!-- /.page-header -->

        <div class="projects-one">
            <div class="container">
                <div class="row">
                    <?php include 'koneksi.php';
                    $tampil=mysqli_query($konek, "SELECT * FROM tb_project ");
                    while ($data=mysqli_fetch_array($tampil, MYSQLI_ASSOC)) {?>
                    <div class="col-sm-12 col-md-6 col-lg-4">
                        <div class="projects-one__single">
                            <img src="./berkas/<?php echo $data['gam_awl']; ?>" alt="">
                            <div class="projects-one__content">
                                <h3>Detail Project</h3>
                                <a href="project-details.php?id=<?php echo $data['id_prj']; ?>" class="projects-one__button"><i class="agrikon-icon-right-arrow"></i></a><!-- /.projects-one__button -->
                            </div><!-- /.projects-one__content -->
                        </div><!-- /.projects-one__single -->
                    </div><!-- /.col-sm-12 -->
                    <?php } ?>
                </div><!-- /.row -->
            </div><!-- /.container -->
        </div><!-- /.projects-one -->
<?php include 'tem/footer.php'; ?>