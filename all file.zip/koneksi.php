<?php 
$host ="localhost:8111";
$user ="root";
$pass ="";
$db="db_car";

$konek =mysqli_connect($host, $user, $pass, $db);


 ?>