<?php 
include 'koneksi.php';
$yt =$_POST['yt'];
$tiktok =$_POST['tiktok'];
$fb =$_POST['fb'];
$ig =$_POST['ig'];
$email =$_POST['email'];
$alamat =$_POST['alamat'];
$no_hp =$_POST['no_hp'];

$simpan=mysqli_query($konek, "INSERT INTO `tb_media` (`id_soc`,`yt`,`tiktok`,`fb`,`ig`,`email`,`alamat`,`no_hp`) VALUES (null, '$yt','$tiktok','$fb','$ig','$email','$alamat','$no_hp')");

header("location:dashboard_admin.php?p=data_media");

 ?>