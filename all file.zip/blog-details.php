<?php include 'tem/header.php'; ?>
        <div class="stricky-header stricked-menu main-menu">
            <div class="sticky-header__content"></div><!-- /.sticky-header__content -->
        </div><!-- /.stricky-header -->
        <section class="page-header">
            <div class="page-header__bg" ></div>
            <!-- /.page-header__bg -->
            <div class="container">
                <ul class="thm-breadcrumb list-unstyled">
                    <li><a href="index.php">Home</a></li>
                    <li>/</li>
                    <li><span>Detail Berita</span></li>
                </ul><!-- /.thm-breadcrumb list-unstyled -->
                <h2>Detail Berita</h2>
            </div><!-- /.container -->
        </section><!-- /.page-header -->


        <section class="blog-details">
            <div class="container">
                <div class="row">
                    <?php include 'koneksi.php';
                    $id =$_GET['id'];
                    $tampil=mysqli_query($konek, "SELECT * FROM tb_berita WHERE id_berita='$id'");
                    while ($data=mysqli_fetch_array($tampil, MYSQLI_ASSOC)) {?>
                    <div class="col-lg-8">
                        <div class="blog-details__image">
                            <img src="./berkas/<?php echo $data['foto']; ?>" class="img-fluid" alt="">
                        </div><!-- /.blog-details__image -->
                        <div class="blog-card__content">
                            <div class="blog-card__date" style="font-size: 10px;"><?php echo $data['tgl_muat']; ?></div><!-- /.blog-card__date -->
                            <div class="blog-card__meta">
                                <a href=""><i class="far fa-user-circle"></i> by <?php echo $data['nm_penulis']; ?></a>
                            </div><!-- /.blog-card__meta -->
                            <h3><a href=""><?php echo $data['judul']; ?></a></h3>
                        </div><!-- /.blog-card__content -->
                        <div class="blog-details__content">
                            <p> </p>
                            <p>
                                <?php echo $data['isi']; ?>
                            </p>
                        </div><!-- /.blog-details__content -->

                        <div class="blog-details__meta">
                            <div class="blog-details__tags">
                                <span>Tags:</span>
                                <a href="#">Teknologi</a>
                                <a href="#">Makanan</a>
                                <a href="#">Wisata</a>
                            </div><!-- /.blog-details__tags -->
                            <div class="blog-details__social">
                                <a href="#"><i class="fab fa-facebook-f"></i></a>
                                <a href="#"><i class="fab fa-youtube"></i></a>
                                <a href="#"><i class="fab fa-instagram"></i></a>
                            </div><!-- /.blog-details__social -->
                        </div><!-- /.blog-details__meta -->

                    </div><!-- /.col-lg-8 -->
                <?php } ?>
                    <div class="col-lg-4">
                        <div class="blog-sidebar">
                            <div class="blog-sidebar__search">
                                <form action="#" method="post">
                                    <input type="text" placeholder="Cari">
                                    <button type="submit"><i class="agrikon-icon-magnifying-glass"></i></button>
                                </form>
                            </div><!-- /.blog-sidebar__search -->

                            <div class="blog-sidebar__categories">
                                <h3>Kategori</h3>
                                <ul>
                                    <?php include 'koneksi.php';
                                $data_tam=mysqli_query($konek, "SELECT * FROM tb_berita");
                                while ($data_a=mysqli_fetch_array($data_tam, MYSQLI_ASSOC)) { ?>
                                    <li>
                                        <a href="blog-details.php?id=<?php echo $data_a['id_berita']; ?>"><i class="agrikon-icon-right-arrow"></i><?php echo $data_a['kategori']; ?>
                                        </a>
                                    </li>
                                    <?php } ?>
                                </ul>
                            </div><!-- /.blog-sidebar__categories -->

                        </div><!-- /.blog-sidebar -->
                    </div><!-- /.col-lg-4 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </section><!-- /.blog-details -->
<?php include 'tem/footer.php'; ?>