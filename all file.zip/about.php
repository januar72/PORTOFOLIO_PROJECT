<?php include 'tem/header.php'; ?>
        <div class="stricky-header stricked-menu main-menu">
            <div class="sticky-header__content"></div><!-- /.sticky-header__content -->
        </div><!-- /.stricky-header -->
        <section class="page-header">
            <div class="page-header__bg"></div>
            <!-- /.page-header__bg -->
            <div class="container">
                <ul class="thm-breadcrumb list-unstyled">
                    <li><a href="index.php">Home</a></li>
                    <li>/</li>
                    <li><span>About</span></li>
                </ul><!-- /.thm-breadcrumb list-unstyled -->
                <h2>Tentang Kami</h2>
            </div><!-- /.container -->
        </section><!-- /.page-header -->

        <section class="service-one service-one__about">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-lg-4">
                        <div class="service-one__box">
                            <img src="depan/assets/images/services/elektro-1-1.jpg" alt="">
                            <div class="service-one__box-content">
                                <h3>Website UMKM</h3>
                            </div><!-- /.service-one__box-content -->
                        </div><!-- /.service-one__box -->
                    </div><!-- /.col-md-12 col-lg-4 -->
                    <div class="col-md-12 col-lg-4">
                        <div class="service-one__box">
                            <img src="depan/assets/images/services/elektro-2-1.jpg" alt="">
                            <div class="service-one__box-content">
                                <h3>Website Destinasi Wisata</h3>
                            </div><!-- /.service-one__box-content -->
                        </div><!-- /.service-one__box -->
                    </div><!-- /.col-md-12 col-lg-4 -->
                    <div class="col-md-12 col-lg-4">
                        <div class="service-one__box">
                            <img src="depan/assets/images/services/elektro-2-3.jpg" alt="">
                            <div class="service-one__box-content">
                                <h3>Website Perusahaan</h3>
                            </div><!-- /.service-one__box-content -->
                        </div><!-- /.service-one__box -->
                    </div><!-- /.col-md-12 col-lg-4 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </section><!-- /.service-one -->


        <section class="team-one">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-lg-12 col-xl-5">
                        <div class="team-one__content">
                            <div class="block-title">
                                <h3>Team Pendukung</h3>
                            </div><!-- /.block-title -->
                            <div class="team-one__summery">
                                <p>Kami Memilki team yang solid dalam mengerjakan project, yang profesional dalam bidangnya masing-masing.</p>
                            </div><!-- /.team-one__summery -->

                            <!-- If we need navigation buttons -->
                            <div class="team-one__nav">
                                <div class="swiper-button-prev" id="team-one__swiper-button-next"><i class="agrikon-icon-left-arrow"></i>
                                </div>

                                <div class="swiper-button-next" id="team-one__swiper-button-prev"><i class="agrikon-icon-right-arrow"></i></div>
                            </div><!-- /.team-one__nav -->

                        </div><!-- /.team-one__content -->
                    </div><!-- /.col-md-12 col-lg-5 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
            <div class="team-one__carousel-wrap">
                <div class="thm-swiper__slider swiper-container" data-swiper-options='{"spaceBetween": 0, "slidesPerView": 1, "slidesPerGroup": 1, "autoplay": { "delay": 5000 }, "navigation": {
            "nextEl": "#team-one__swiper-button-next",
            "prevEl": "#team-one__swiper-button-prev"
        },"breakpoints": {
            "0": {
                "spaceBetween": 0,
                "slidesPerView": 1,
                "slidesPerGroup": 1
            },
            "640": {
                "spaceBetween": 30,
                "slidesPerView": 2,
                "slidesPerGroup": 2
            },
            "992": {
                "spaceBetween": 30,
                "slidesPerView": 3,
                "slidesPerGroup": 3
            },
            "1200": {
                "spaceBetween": 30,
                "slidesPerView": 3,
                "slidesPerGroup": 3
            }
        }}'>

                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <div class="team-card">
                                <div class="team-card__image">
                                    <img src="depan/assets/images/team/avatar.png" alt="Jessica Brown">
                                    <div class="team-card__social">
                                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                                        <a href="#"><i class="fab fa-instagram"></i></a>
                                        <a href="#"><i class="fab fa-linkedin-in"></i></a>
                                    </div><!-- /.team-card__social -->
                                </div><!-- /.team-card__image -->
                                <h3>Januar</h3>
                                <p>Backend Developer</p>
                            </div><!-- /.team-card -->
                        </div><!-- /.swiper-slide -->
                        <div class="swiper-slide">
                            <div class="team-card">
                                <div class="team-card__image">
                                    <img src="depan/assets/images/team/avatar2.png" alt="Jessica Brown">
                                    <div class="team-card__social">
                                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                                        <a href="#"><i class="fab fa-instagram"></i></a>
                                        <a href="#"><i class="fab fa-linkedin-in"></i></a>
                                    </div><!-- /.team-card__social -->
                                </div><!-- /.team-card__image -->
                                <h3>Lusty</h3>
                                <p>Frontend Developer</p>
                            </div><!-- /.team-card -->
                        </div><!-- /.swiper-slide -->
                        <div class="swiper-slide">
                            <div class="team-card">
                                <div class="team-card__image">
                                    <img src="depan/assets/images/team/avatar3.png" alt="Jessica Brown">
                                    <div class="team-card__social">
                                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                                        <a href="#"><i class="fab fa-instagram"></i></a>
                                        <a href="#"><i class="fab fa-linkedin-in"></i></a>
                                    </div><!-- /.team-card__social -->
                                </div><!-- /.team-card__image -->
                                <h3>Daria</h3>
                                <p>System Analist</p>
                            </div><!-- /.team-card -->
                        </div><!-- /.swiper-slide -->
                        <div class="swiper-slide">
                            <div class="team-card">
                                <div class="team-card__image">
                                    <img src="depan/assets/images/team/avatar.png" alt="Jessica Brown">
                                    <div class="team-card__social">
                                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                                        <a href="#"><i class="fab fa-instagram"></i></a>
                                        <a href="#"><i class="fab fa-linkedin-in"></i></a>
                                    </div><!-- /.team-card__social -->
                                </div><!-- /.team-card__image -->
                                <h3>Januar</h3>
                                <p>Backend Developer</p>
                            </div><!-- /.team-card -->
                        </div><!-- /.swiper-slide -->
                        <div class="swiper-slide">
                            <div class="team-card">
                                <div class="team-card__image">
                                    <img src="depan/assets/images/team/avatar2.png" alt="Jessica Brown">
                                    <div class="team-card__social">
                                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                                        <a href="#"><i class="fab fa-instagram"></i></a>
                                        <a href="#"><i class="fab fa-linkedin-in"></i></a>
                                    </div><!-- /.team-card__social -->
                                </div><!-- /.team-card__image -->
                                <h3>Lusti</h3>
                                <p>Frontend Developer</p>
                            </div><!-- /.team-card -->
                        </div><!-- /.swiper-slide -->
                        <div class="swiper-slide">
                            <div class="team-card">
                                <div class="team-card__image">
                                    <img src="depan/assets/images/team/avatar3.png" alt="Jessica Brown">
                                    <div class="team-card__social">
                                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                                        <a href="#"><i class="fab fa-instagram"></i></a>
                                        <a href="#"><i class="fab fa-linkedin-in"></i></a>
                                    </div><!-- /.team-card__social -->
                                </div><!-- /.team-card__image -->
                                <h3>Daria</h3>
                                <p>System Analist</p>
                            </div><!-- /.team-card -->
                        </div><!-- /.swiper-slide -->
                    </div><!-- /.swiper-wrapper -->

                </div><!-- /.thm-swiper__slider -->
            </div><!-- /.team-one__carousel-wrap -->
        </section><!-- /.team-one -->

        <section class="about-one">
            <div class="container">
                <div class="row">
                    <div class="col-lg-5">
                        <div class="about-one__images">
                            <img src="depan/assets/images/resources/about-1-1.jpg" alt="">
                            <div class="about-one__count wow fadeInLeft" data-wow-duration="1500ms">
                                <span>Free Maintenance</span>
                                <h4>24 Jam</h4>
                            </div><!-- /.about-one__count -->
                        </div><!-- /.about-one__images -->
                    </div><!-- /.col-lg-6 -->
                    <div class="col-lg-7">
                        <div class="about-one__content">
                            <div class="block-title text-left">
                                <p>Welcome to Jl Project</p>
                                <h3>Teknologi untuk Masa Depan yang Lebih Baik</h3>
                            </div><!-- /.block-title -->
                            <div class="about-one__tagline">
                                <p>Kami memiliki pengalaman 5 tahun dalam pengembangan teknologi.</p>
                            </div><!-- /.about-one__tagline -->
                            <div class="about-one__summery">
                                <p>There are many variations of passages of lorem ipsum available but the majority have suffered
                                    alteration in some form by injected humor or random word which don't look even.</p>
                            </div><!-- /.about-one__summery -->
                            <div class="about-one__icon-row">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="about-one__box">
                                             <i class="fa fa-laptop"></i> 
                                            <h4><a href="#">Professional developer</a></h4>
                                        </div><!-- /.about-one__box -->
                                    </div><!-- /.col-lg-6 -->
                                    <div class="col-lg-6">
                                        <div class="about-one__box">
                                            <i class="fa fa-fw fa-cogs"></i> 
                                            <h4><a href="">Free Maintenance</a></h4>
                                        </div><!-- /.about-one__box -->
                                    </div><!-- /.col-lg-6 -->
                                </div><!-- /.row -->
                            </div><!-- /.about-one__icon-row -->
                            <a href="projects.php" class="thm-btn">Lihat Selanjutnya</a><!-- /.thm-btn -->
                        </div><!-- /.about-one__content -->
                    </div><!-- /.col-lg-6 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </section><!-- /.about-one -->
<?php include 'tem/footer.php'; ?>