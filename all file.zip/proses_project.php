<?php 
include 'koneksi.php';
if (isset($_POST['simpan'])) {
	$direktori ="berkas/";
	$file_name =$_FILES['gam_awl']['name'];
	$nama_file =$_FILES['foto']['name'];
	move_uploaded_file($_FILES['gam_awl']['tmp_name'],$direktori.$file_name);
	move_uploaded_file($_FILES['foto']['tmp_name'],$direktori.$nama_file);

	$judul =$_POST['judul'];
	$tgl =$_POST['tgl'];
	$pelanggan =$_POST['pelanggan'];
	$kategori =$_POST['kategori'];
	$layanan =$_POST['layanan'];
	$isi =$_POST['isi'];

	$simpan =mysqli_query($konek, "INSERT INTO `tb_project` (`id_prj`,`gam_awl`,`judul`,`tgl`,`pelanggan`,`kategori`,`layanan`,`foto`,`isi`) VALUES (null, '$file_name', '$judul','$tgl','$pelanggan','$kategori','$layanan','$nama_file','$isi')");

	header("location:dashboard_admin.php?p=data_project");
}

 ?>