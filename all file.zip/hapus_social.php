<?php 
include 'koneksi.php';

$id =$_GET['id'];

$hapus =mysqli_query($konek, "DELETE FROM tb_media WHERE id_soc='$id'");
header("location:dashboard_admin.php?p=data_media");

 ?>