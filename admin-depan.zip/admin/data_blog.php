<section class="content-header">
	<h1>
		<small>Blog Berita</small>
	</h1>
	<ol class="breadcrumb">
		<li><a href=""><i class="fa fa-dashboard"> Dashboard</i></a></li>
		<li><a href="">Admin</a></li>
		<li class="active">Blog Berita</li>
	</ol>
</section>
<section class="content">
	<div class="row">
		<div class="col-lg-12">
			<div class="box box-success">
				<div class="box-header with-border">
					<h3 class="box-title">Input Berita</h3>
				</div>
				<div class="box-body" style="overflow: auto;">
					<form method="post" action="proses_berita.php" enctype="multipart/form-data">
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label>Judul</label>
									<textarea cols="3" rows="4" name="judul" class="form-control"></textarea>
								</div>
							</div>
							<div class="col-lg-4">
								<div class="form-group">
									<label>Kategori</label>
									<textarea cols="3" rows="3" name="kategori" class="form-control"></textarea>
								</div>
							</div>
							<div class="col-lg-2">
								<div class="form-group">
									<label>Foto Content(370 x 244)</label>
									<input type="file" name="gambar" class="form-control" required>
								</div>
							</div>
						</div>

						<div class="row">
							<div class="col-lg-4">
								<div class="form-group">
									<label>Tgl Muat</label>
									<input type="date" name="tgl_muat" class="form-control" required>
								</div>
							</div>
							<div class="col-lg-4">
								<div class="form-group">
									<label>Nama Penulis</label>
									<input type="text" name="nm_penulis" class="form-control" required>
								</div>
							</div>
							<div class="col-lg-4">
								<div class="form-group">
									<label>Foto Berita(770 x 419)</label>
									<input type="file" name="foto" class="form-control" required>
								</div>
							</div>
						</div>
						<div class="form-group">
							<textarea name="isi" id="editor1" name="editor1" rows="10" cols="80">
                    		</textarea>
						</div>
						<div class="box-footer">
							<input type="submit" name="simpan" class="btn btn-primary">
						</div>
					</form>
				</div>
			</div>
		</div>
		<div class="col-lg-12">
			<div class="box box-success">
				<div class="box-header with-border">
					<h3 class="box-title">Tabel Berita</h3>
				</div>
				<div class="box-body" style="overflow: auto;">
					<table id="example1" class="table table-bordered table-striped">
						<thead>
							<tr>
								<th>No</th>
								<th>Judul</th>
								<th>Kategori</th>
								<th><br>
									<i style="font-size: 8px;">*click gambar</i></th>
								<th>Tgl Muat</th>
								<th>Nama Penulis</th>
								<th><br>
									<i style="font-size: 8px;">*click</i></th>
								<th>Isi Berita</th>
								<th>Aksi</th>
							</tr>
						</thead>
						<tbody>
							<?php include 'koneksi.php';
							$no=1;
							$tampil=mysqli_query($konek, "SELECT * FROM tb_berita");
							while ($data=mysqli_fetch_array($tampil, MYSQLI_ASSOC)) {?>
								<tr>
									<td><?php echo $no++; ?></td>
									<td><?php echo $data['judul']; ?></td>
									<td><?php echo $data['kategori']; ?></td>
									<td>
										<a href="dashboard_admin.php?p=gambar_a&gambar_a=<?php echo $data['gambar']; ?>" class="btn btn-success" style="padding: 0;">
											<img src="./berkas/<?php echo $data['gambar']; ?>" style="width: 50px; height:50px;">
										</a>
									</td>
									<td><?php echo $data['tgl_muat']; ?></td>
									<td><?php echo $data['nm_penulis']; ?></td>
									<td>
										<a href="dashboard_admin.php?p=foto&foto=<?php echo $data['foto']; ?>" class="btn btn-primary" style="padding: 0;">
											<img src="./berkas/<?php echo $data['foto']; ?>" style="width: 50px; height:50px;">
										</a>
									</td>
									<td><?php echo $data['isi']; ?></td>
									<td>
										<a href="hapus_berita.php?id=<?php echo $data['id_berita']; ?>" class="btn btn-success btn-xs"><i class="fa fa-trash"></i></a>
									</td>
								</tr>
							<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</section>