  <!-- Content Header (Page header) -->
      <section class="content-header">
        
      </section>
      <section class="content" style="padding-top: 4rem;">
        <div class="row">
          <div class="col-lg-12">
            <div class="box box-default">
              <div class="box-header with-border">
                <h3 class="box-title">Gambar Project </h3>
              </div>
              <div class="box-body" style="width: auto; overflow-x: auto;">
                <?php
                  $gam_awl=$_GET['gam_awl'];
                ?>
                <img src="./berkas/<?php echo $gam_awl;?>">
             </div>
            </div>
            <button class="block btn btn-danger" type="button"><a href="dashboard_admin.php?p=data_project" style="color: white;">Back</a></button>
          </div>
        </div>
      </section>
      <!-- /.content -->