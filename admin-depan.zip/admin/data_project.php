<section class="content-header">
	<h1>
		<small>Data Project</small>
	</h1>
	<ol class="breadcrumb">
		<li><a href=""><i class="fa fa-dashboard"> Dashboard</i></a></li>
		<li><a href="">Admin</a></li>
		<li class="active">Data Project</li>
	</ol>
</section>
<section class="content">
	<div class="row">
		<div class="col col-lg-4">
			<div class="box box-success">
				<div class="box-header with-border">
					<h3 class="box-title">Input Project</h3>
				</div>
				<div class="box-body" style="overflow: auto;">
					<form method="post" action="proses_project.php" enctype="multipart/form-data">
						<div class="form-group">
							<label>Gambar Awal(370 x 452)</label>
							<input type="file" name="gam_awl" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Judul</label>
							<textarea cols="3" rows="3" name="judul" class="form-control" required></textarea>
						</div>
						<div class="form-group">
							<label>Tanggal Terbit</label>
							<input type="date" name="tgl" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Client</label>
							<input type="text" name="pelanggan" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Kategori</label>
							<input type="text" name="kategori" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Layanan</label>
							<input type="text" name="layanan" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Foto Content(1170 x 532)</label>
							<input type="file" name="foto" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Penjelasan Ptroject</label>
							<textarea cols="5" rows="10" name="isi" class="form-control"></textarea>
						</div>
						<div class="box-footer">
							<input type="submit" name="simpan" class="btn btn-primary">
						</div>
					</form>
				</div>
			</div>
		</div>
		<div class="col-lg-8">
			<div class="box box-success">
				<div class="box-header with-border">
					<h3 class="box-title">Tabel Project</h3>
				</div>
				<div class="box-body" style="overflow: auto;">
					<table id="example1" class="table table-bordered table-striped">
						<thead>
							<tr>
								<th>No</th>
								<th>Judul</th>
								<th>Tanggal</th>
								<th>Client</th>
								<th>Kategori</th>
								<th><br>
									<i style="font-size:8ppx;">*foto content</i></th>
								<th>Layanan</th>
								<th>Ketrangan</th>
								<th><br>
									<i style="font-size: 8px;">*Click Gambar</i></th>
								<th>Aksi</th>
							</tr>
						</thead>
						<tbody>
							<?php include 'koneksi.php';
							$no=1;
							$tampil=mysqli_query($konek, "SELECT * FROM tb_project");
							while ($data=mysqli_fetch_array($tampil, MYSQLI_ASSOC)) {?>
								<tr>
									<td><?php echo $no++; ?></td>
									<td><?php echo $data['judul']; ?></td>
									<td><?php echo $data['tgl']; ?></td>
									<td><?php echo $data['pelanggan']; ?></td>
									<td><?php echo $data['kategori']; ?></td>
									<td>
										<a href="dashboard_admin.php?p=gam_awl&gam_awl=<?php echo $data['gam_awl']; ?>" class="btn btn-primary" style="padding: 0;">
											<img src="./berkas/<?php echo $data['gam_awl']; ?>" style="width: 50px; height:50px;">
										</a>
									</td>
									<td><?php echo $data['layanan']; ?></td>
									<td><?php echo $data['isi']; ?></td>
									<td>
										<a href="dashboard_admin.php?p=fotoa&fotoa=<?php echo $data['foto']; ?>" class="btn btn-success" style="padding: 0;">
											<img src="./berkas/<?php echo $data['foto']; ?>" style="width: 50px; height:50px;">
										</a>
									</td>
									<td>
										<a href="hapus_project.php?id=<?php echo $data['id_prj']; ?>"><i class="fa fa-trash"></i></a>
									</td>
								</tr>
							<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</section>