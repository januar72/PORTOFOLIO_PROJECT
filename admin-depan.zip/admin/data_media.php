<section class="content-header">
	<h1>
		<small>Social Media</small>
	</h1>
	<ol class="breadcrumb">
		<li><a href=""><i class="fa fa-dashboard"> Dashboard</i></a></li>
		<li><a href="">Admin</a></li>
		<li class="active">Social Media</li>
	</ol>
</section>
<section class="content">
	<div class="row">
		<div class="col-lg-4">
			<div class="box box-success">
				<div class="box-header with-border">
					<h3 class="box-title">Input Social Media</h3>
				</div>
				<div class="box-body" style="overflow: auto;">
					<form method="post" action="proses_socialm.php">
						<div class="form-group">
							<label>Youtube</label>
							<input type="text" name="yt" class="form-control">
						</div>
						<div class="row">
							<div class="col-lg-6">
								<label>Tik tok</label>
								<input type="text" name="tiktok" class="form-control">
							</div>
							<div class="col-lg-6">
								<label>Facebook</label>
								<input type="text" name="fb" class="form-control" required>
							</div>
						</div>
						<div class="form-group">
							<label>Instagram</label>
							<input type="text" name="ig" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Email</label>
							<input type="email" name="email" class="form-control">
						</div>
						<div class="row">
							<div class="col-lg-6">
								<label>Alamat</label>
								<input type="text" name="alamat" class="form-control" required>
							</div>
							<div class="col-lg-6">
								<label>No Hp</label>
								<input type="text" name="no_hp" class="form-control" required>
							</div>
						</div>
						<div class="box-footer">
							<input type="submit" name="simpan" class="btn btn-primary">
						</div>
					</form>
				</div>
			</div>
		</div>
		<div class="col-lg-8">
			<div class="box box-success">
				<div class="box-header with-border">
					<h3 class="box-title">Tabel Social Media</h3>
				</div>
				<div class="box-body" style="overflow: auto;">
					<table id="example1" class="table table-bordered table-striped">
						<thead>
							<tr>
								<th>No</th>
								<th>Youtube</th>
								<th>Tik tok</th>
								<th>Facebook</th>
								<th>Instagram</th>
								<th>Email</th>
								<th>Alamat</th>
								<th>No Hp</th>
								<th>Aksi</th>
							</tr>
						</thead>
						<tbody>
							<?php include 'koneksi.php';
							$no =1;
							$tampil=mysqli_query($konek, "SELECT * FROM tb_media");
							while ($data=mysqli_fetch_array($tampil, MYSQLI_ASSOC)) {?>
								<tr>
									<td><?php echo $no++; ?></td>
									<td><?php echo $data['yt']; ?></td>
									<td><?php echo $data['tiktok']; ?></td>
									<td><?php echo $data['fb']; ?></td>
									<td><?php echo $data['ig']; ?></td>
									<td><?php echo $data['email']; ?></td>
									<td><?php echo $data['alamat']; ?></td>
									<td><?php echo $data['no_hp']; ?></td>
									<td>
										<a href="hapus_social.php?id=<?php echo $data['id_soc']; ?>" class="btn btn-success btn-xs"><i class="fa fa-trash"></i></a>
									</td>
								</tr>
							<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</section>