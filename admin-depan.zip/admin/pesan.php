<div class="content">
  <div class="col-lg-12">
          <!-- DIRECT CHAT SUCCESS -->
          <div class="box box-success direct-chat direct-chat-success">
            <div class="box-header with-border">
              <h3 class="box-title">Pesan Masuk</h3>
              <div class="box-tools pull-right">
                <?php include 'koneksi.php';
              $id= $_GET['id'];
              $tampil_b="SELECT * FROM tb_pesan WHERE id_pesan='$id'";
              $query_order_a=mysqli_query($konek, $tampil_b);
              $data_order_b=array();
              while (($row_order=mysqli_fetch_array($query_order_a)) !=null) {
                 $data_order_b[]=$row_order;
               }
               $jumlah=count($data_order_b); {?>
                <span data-toggle="tooltip" title="<?php echo $jumlah; ?> New Messages" class="badge bg-green"><?php echo $jumlah; ?></span>
              <?php } ?>
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-toggle="tooltip" title="Contacts" data-widget="chat-pane-toggle">
                  <i class="fa fa-comments"></i></button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <!-- Conversations are loaded here -->
              <div class="direct-chat-messages">
                <!-- Message. Default to the left -->
                <div class="direct-chat-msg">
                  <?php include 'koneksi.php';
                  $id =$_GET['id'];
                  $tampil_a=mysqli_query($konek, "SELECT * FROM tb_pesan WHERE id_pesan='$id'");
                  while ($data=mysqli_fetch_array($tampil_a)) {?>
                  <div class="direct-chat-info clearfix">
                    <span class="direct-chat-name pull-left"><?php echo $data['nama']; ?></span>
                    <span class="direct-chat-timestamp pull-right"><?php echo date('d-m-Y'); ?></span>
                  </div>
                  <!-- /.direct-chat-info -->
                  <img class="direct-chat-img" src="./dist/img/avatar.png" alt="Message User Image"><!-- /.direct-chat-img -->
                  <div class="direct-chat-text">
                    <?php echo $data['pesan']; ?>
                  </div>
                  <!-- /.direct-chat-text -->
                  <?php } ?>
                </div>
                <!-- /.direct-chat-msg -->
              </div>
              <!--/.direct-chat-messages-->

            </div>
            <!-- /.box-body -->
            <div class="box-footer">
              <form action="#" method="post">
                <div class="input-group">
                  <input type="text" name="message" placeholder="Type Message ..." class="form-control">
                      <span class="input-group-btn">
                        <button type="submit" class="btn btn-success btn-flat">Send</button>
                      </span>
                </div>
              </form>
            </div>
            <!-- /.box-footer-->
          </div>
          <!--/.direct-chat -->
        </div>
        <!-- /.col -->
</div>

