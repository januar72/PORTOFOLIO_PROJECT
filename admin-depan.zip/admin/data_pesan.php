<section class="content-header">
	<h1>
		<small>Data Pesan</small>
	</h1>
	<ol class="breadcrumb">
		<li><a href=""><i class="fa fa-dashboard"> Dashboard</i></a></li>
		<li><a href="">Admin</a></li>
		<li class="active">Data Pesan</li>
	</ol>
</section>
<section class="content">
	<div class="row">
		<div class="col-lg-12">
			<div class="box box-success">
				<div class="box-header with-border">
					<h3 class="box-title">Tabel Pesan</h3>
				</div>
				<div class="box-body" style="overflow: auto;">
					<table id="example1" class="table table-bordered table-striped">
						<thead>
							<tr>
								<th>No</th>
								<th>Nama</th>
								<th>Email</th>
								<th>No Hp</th>
								<th>Pesan</th>
								<th>Aksi</th>
							</tr>
						</thead>
						<tbody>
							<?php include 'koneksi.php';
							$no=1;
							$tampil=mysqli_query($konek, "SELECT * FROM tb_pesan");
							while ($data=mysqli_fetch_array($tampil, MYSQLI_ASSOC)) {?>
								<tr>
									<td><?php echo $no++; ?></td>
									<td><?php echo $data['nama']; ?></td>
									<td><?php echo $data['email']; ?></td>
									<td><?php echo $data['hp']; ?></td>
									<td><?php echo $data['pesan']; ?></td>
									<td>
										<a href="hapus_pesan.php?id=<?php echo $data['id_pesan']; ?>"><i class="fa fa-trash"></i></a>
									</td>
								</tr>
							<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</section>