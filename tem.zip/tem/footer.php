
         <footer class="site-footer">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-md-6 col-lg-6 col-xl-4">
                        <div class="footer-widget">
                            
                            <p>Halo Selamat Datang di Jl Project
                            </p>
                            <?php include 'koneksi.php';
                            $tampil=mysqli_query($konek, "SELECT * FROM tb_media");
                            while ($data=mysqli_fetch_array($tampil, MYSQLI_ASSOC)) {?>
                            <form action="<?php echo $data['email']; ?>" data-url="YOUR_MAILCHIMP_URL" class="mc-form">
                                <input type="email" name="EMAIL" placeholder="Alamat Email..">
                                <button type="submit"><i class="agrikon-icon-right-arrow"></i></button>
                            </form><!-- /.mc-form -->
                            <div class="mc-form__response"></div><!-- /.mc-form__response -->
                            <div class="footer__social">
                                <a href="<?php echo $data['fb']; ?>" class="fab fa-facebook-square"></a>
                                <a href="<?php echo $data['yt']; ?>" class="fab fa-youtube"></a>
                                <a href="<?php echo $data['ig']; ?>" class="fab fa-instagram"></a>
                            </div><!-- /.topbar__social -->
                            <?php } ?>
                        </div><!-- /.footer-widget -->
                    </div><!-- /.col-sm-12 col-md-6 col-lg-4 -->
                    <div class="col-sm-12 col-md-6 col-lg-6 col-xl-2">
                        <div class="footer-widget footer-widget__links-widget">
                            <h3 class="footer-widget__title">Links</h3><!-- /.footer-widget__title -->
                            <ul class="list-unstyled footer-widget__links">
                                <li><a href="projects.php">Projects</a></li>
                                <li><a href="about.php">About</a></li>
                                <li><a href="#">Kontak</a></li>
                            </ul><!-- /.list-unstyled -->
                        </div><!-- /.footer-widget -->
                    </div><!-- /.col-sm-12 col-md-6 col-lg-2 -->
                    <div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
                        <div class="footer-widget">
                            <h3 class="footer-widget__title">Berita</h3><!-- /.footer-widget__title -->
                            <ul class="list-unstyled footer-widget__post">
                                <li>
                                    <img src="depan/assets/images/resources/berita.jpg" alt="">
                                    <div class="footer-widget__post-content">
                                        <span><?php echo date('d-m-Y'); ?></span>
                                        <h4><a href="blog.php">Lihat berita terbaru kita disini.</a></h4>
                                    </div><!-- /.footer-widget__post-content -->
                                </li>
                            </ul><!-- /.list-unstyled footer-widget__post -->
                        </div><!-- /.footer-widget -->
                    </div><!-- /.col-sm-12 col-md-6 col-lg-3 -->
                    <div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
                        <h3 class="footer-widget__title">Contact</h3><!-- /.footer-widget__title -->
                        <ul class="list-unstyled footer-widget__contact">
                            <?php include 'koneksi.php';
                            $data_a=mysqli_query($konek, "SELECT * FROM tb_media");
                            while ($data_b=mysqli_fetch_array($data_a, MYSQLI_ASSOC)) { ?>
                            <li>
                                <i class="agrikon-icon-telephone"></i>
                                <a href="tel:<?php echo $data_b['no_hp']; ?>"><?php echo $data_b['no_hp']; ?></a>
                            </li>
                            <li>
                                <i class="agrikon-icon-email"></i>
                                <a href="<?php echo $data_b['email']; ?>"><?php echo $data_b['email']; ?></a>
                            </li>
                            <li>
                                <i class="agrikon-icon-pin"></i>
                                <a href="<?php echo $data_b['alamat']; ?>"><?php echo $data_b['alamat']; ?></a>
                            </li>
                        <?php } ?>
                        </ul><!-- /.list-unstyled -->
                    </div><!-- /.col-sm-12 col-md-6 col-lg-3 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </footer><!-- /.site-footer -->
        <div class="bottom-footer">
            <div class="container">
                <p>© Copyright <?php echo date('Y'); ?> by <a href="" style="color: salmon;">januar</a></p>
                <div class="bottom-footer__links">
                    <a href="#">Privacy Policy</a>
                    <a href="#">Since <?php echo date('Y'); ?></a>
                </div><!-- /.bottom-footer__links -->
            </div><!-- /.container -->
        </div><!-- /.bottom-footer -->

    </div><!-- /.page-wrapper -->


    <div class="mobile-nav__wrapper">
        <div class="mobile-nav__overlay mobile-nav__toggler"></div>
        <!-- /.mobile-nav__overlay -->
        <div class="mobile-nav__content">
            <span class="mobile-nav__close mobile-nav__toggler"><i class="far fa-times"></i></span>

            <div class="logo-box">
                <a href="index.php" aria-label="logo image">
                    <span>Jl</span> Project
                </a>
            </div>
            <!-- /.logo-box -->
            <div class="mobile-nav__container"></div>
            <!-- /.mobile-nav__container -->

            <ul class="mobile-nav__contact list-unstyled">
                <?php include 'koneksi.php';
                $cam=mysqli_query($konek, "SELECT * FROM tb_media");
                while ($data_a=mysqli_fetch_array($cam, MYSQLI_ASSOC)) {?>
                <li>
                    <i class="agrikon-icon-email"></i>
                    <a href="<?php echo $data_a['email']; ?>"><?php echo $data_a['email']; ?></a>
                </li>
                <li>
                    <i class="agrikon-icon-telephone"></i>
                    <a href="tel:<?php echo $data_a['email']; ?>"><?php echo $data_a['no_hp']; ?></a>
                </li>
                <?php } ?>
            </ul><!-- /.mobile-nav__contact -->

            <div class="mobile-nav__top">
                <div class="mobile-nav__social">
                    <?php include 'koneksi.php';
                    $data_c=mysqli_query($konek, "SELECT * FROM tb_media");
                    while ($data=mysqli_fetch_array($data_c, MYSQLI_ASSOC)) {?>
                    <a href="<?php echo $data['fb']; ?>" aria-label="facebook"><i class="fab fa-facebook-square"></i></a>

                    <a href="<?php echo $data['yt']; ?>" aria-label="youtube"><i class="fab fa-youtube"></i></a>
                    <a href="<?php echo $data['ig']; ?>" aria-label="instagram"><i class="fab fa-instagram"></i></a>
                    <?php } ?>
                </div><!-- /.mobile-nav__social -->
            </div><!-- /.mobile-nav__top -->



        </div>
        <!-- /.mobile-nav__content -->
    </div>
    <!-- /.mobile-nav__wrapper -->

    <div class="search-popup">
        <div class="search-popup__overlay search-toggler"></div>
        <!-- /.search-popup__overlay -->
        <div class="search-popup__content">
            <form action="#">
                <label for="search" class="sr-only">Cari disini</label><!-- /.sr-only -->
                <input type="text" id="search" placeholder="cari disini..." />
                <button type="submit" aria-label="search submit" class="thm-btn">
                    <i class="fa fa-search"></i>
                </button>
            </form>
        </div>
        <!-- /.search-popup__content -->
    </div>
    <!-- /.search-popup -->

    <a href="#" data-target="html" class="scroll-to-target scroll-to-top"><i class="fa fa-angle-up"></i></a>


    <script src="depan/assets/js/jquery-3.5.1.min.js"></script>
    <script src="depan/assets/js/bootstrap.bundle.min.js"></script>
    <script src="depan/assets/js/swiper.min.js"></script>
    <script src="depan/assets/js/jquery.ajaxchimp.min.js"></script>
    <script src="depan/assets/js/jquery.magnific-popup.min.js"></script>
    <script src="depan/assets/js/jquery.validate.min.js"></script>
    <script src="depan/assets/js/bootstrap-select.min.js"></script>
    <script src="depan/assets/js/wow.js"></script>
    <script src="depan/assets/js/odometer.min.js"></script>
    <script src="depan/assets/js/jquery.appear.min.js"></script>
    <script src="depan/assets/js/jarallax.min.js"></script>
    <script src="depan/assets/js/circle-progress.min.js"></script>
    <script src="depan/assets/js/wNumb.min.js"></script>
    <script src="depan/assets/js/nouislider.min.js"></script>

    <!-- template js -->
    <script src="depan/assets/js/theme.js"></script>
</body>

</html>