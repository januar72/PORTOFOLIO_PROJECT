<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JL PROJECT</title>
    <!-- favicons Icons -->
    <meta name="description" content="Agrikon HTML Template For Agriculture Farm & Farmers">

    <!-- fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Handlee&family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="depan/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="depan/assets/css/fontawesome-all.min.css">
    <link rel="stylesheet" href="depan/assets/css/swiper.min.css">
    <link rel="stylesheet" href="depan/assets/css/animate.min.css">
    <link rel="stylesheet" href="depan/assets/css/odometer.min.css">
    <link rel="stylesheet" href="depan/assets/css/jarallax.css">
    <link rel="stylesheet" href="depan/assets/css/magnific-popup.css">
    <link rel="stylesheet" href="depan/assets/css/bootstrap-select.min.css">
    <link rel="stylesheet" href="depan/assets/css/agrikon-icons.css">
    <link rel="stylesheet" href="depan/assets/css/nouislider.min.css">
    <link rel="stylesheet" href="depan/assets/css/nouislider.pips.css">

    <!-- template styles -->
    <link rel="stylesheet" href="depan/assets/css/main.css">
</head>

<body>
    <div class="page-wrapper">
        <header class="main-header">
            <div class="topbar">
                <div class="container">
                    <div class="topbar__left">
                        <div class="topbar__social">
                            <a href="#" class="fab fa-facebook-square"></a>
                            <a href="#" class="fab fa-youtube"></a>
                            <a href="#" class="fab fa-instagram"></a>
                        </div><!-- /.topbar__social -->
                        <p>Selamat Datang Di Jl Project</p>
                    </div><!-- /.topbar__left -->
                    <div class="topbar__right">
                        <a href="#"><i class="agrikon-icon-email"></i>januar@gmail.com</a>
                        <a href="#"><i class="agrikon-icon-clock"></i>hari ini : <?php echo date('d-m-Y'); ?></a>
                    </div><!-- /.topbar__right -->
                </div><!-- /.container -->
            </div><!-- /.topbar -->
            <nav class="main-menu">
                <div class="container">
                    <div class="logo-box">
                        <a href="index.php" aria-label="logo image">
                            <h2><span>Jl</span> Project</h2>
                        </a>
                        <span class="fa fa-bars mobile-nav__toggler"></span>
                    </div><!-- /.logo-box -->
                    <ul class="main-menu__list">
                        <li>
                            <a href="index.php">Home</a>
                        </li>

                        <li>
                            <a href="about.php">About</a>
                        </li>

                        <li class="dropdown">
                            <a href="projects.php">Projects</a>
                            <ul>
                                <li><a href="projects.php">Projects</a></li>
                            </ul>
                        </li>
                        <li class="dropdown"><a href="blog.php">Berita</a>
                            <ul>
                                <li><a href="blog.php">Berita</a></li>
                                <li><a href="login.php">Login</a></li>
                            </ul>
                        </li>
                    </ul>
                    <!-- /.main-menu__list -->

                    <div class="main-header__info">
                        <a href="#" class="search-toggler main-header__search-btn"><i class="agrikon-icon-magnifying-glass"></i></a>

                        <a class="main-header__cart-btn" href="#"><i class="agrikon-icon-shopping-cart"></i></a>

                        <a href="tel:082339619693" class="main-header__info-phone">
                            <i class="agrikon-icon-phone-call"></i>
                            <span class="main-header__info-phone-content">
                                <span class="main-header__info-phone-text">Hubungi Kami</span>
                                <span class="main-header__info-phone-title">082339619693</span>
                            </span><!-- /.main-header__info-phone-content -->
                        </a><!-- /.main-header__info-phone -->
                    </div><!-- /.main-header__info -->
                </div><!-- /.container -->
            </nav>
            <!-- /.main-menu -->
        </header><!-- /.main-header -->